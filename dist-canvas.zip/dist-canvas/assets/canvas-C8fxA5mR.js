(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=Math.min(window.devicePixelRatio||1,2),t=!0,n=document.getElementById(`canvas`),r=`iconMosaic.slider.`;function i(e,t){let n=localStorage.getItem(r+e);return n===null?t:Number(n)}function a(e,t){localStorage.setItem(r+e,String(t))}var o=`iconMosaic.cubeSizeDefaultResetV1`;localStorage.getItem(o)||(localStorage.removeItem(`iconMosaic.slider.cubeSize`),localStorage.setItem(o,`1`));var s=`iconMosaic.dotDefaultsResetV2`;localStorage.getItem(s)||(localStorage.removeItem(`iconMosaic.slider.dotFrequency`),localStorage.removeItem(`iconMosaic.slider.dotSize`),localStorage.setItem(s,`1`));var c=`iconMosaic.plusDefaultsResetV2`;localStorage.getItem(c)||(localStorage.removeItem(`iconMosaic.slider.plusFrequency`),localStorage.removeItem(`iconMosaic.slider.plusSize`),localStorage.setItem(c,`1`));var l=`iconMosaic.modelOffsetDefaultResetV1`;localStorage.getItem(l)||(localStorage.removeItem(`iconMosaic.slider.modelOffsetX`),localStorage.removeItem(`iconMosaic.slider.modelOffsetY`),localStorage.removeItem(`iconMosaic.slider.modelOffsetZ`),localStorage.setItem(l,`1`));var u=i(`pulseWidth`,1)/100,d=i(`flowSpeed`,50),f=i(`flowCoreLength`,60),p=!0,m=i(`flowTailLength`,160),h=i(`flowTailFalloff`,1),g=i(`flowPulseFrequency`,5),_=10,v=1e3,y=i(`cubeSize`,100),b=y/100;function x(e){let t=Math.max(_,Math.min(v,e)),n=b;if(y=t,b=t/100,n>0&&b!==n){let e=b/n;yt=St(yt*e),bt=St(bt*e),xt=St(xt*e)}return t}function S(e){let t=x(e);return a(`cubeSize`,t),Z(),t}var C=i(`lineFrequency`,11),w=i(`dotFrequency`,4),T=i(`dotSize`,5),E=i(`plusFrequency`,2),D=i(`plusSize`,5),ee=.12,O=localStorage.getItem(`iconMosaic.shaderTheme`)===`light`?`light`:`dark`;function k(){return O===`light`?`lightAzimuthLight`:`lightAzimuth`}function A(){return O===`light`?`lightElevationLight`:`lightElevation`}function j(){return O===`light`?`lightIntensityLight`:`lightIntensity`}function M(){return O===`light`?110:160}function te(){return O===`light`?33:50}function ne(){return O===`light`?185:100}var re=i(k(),M()),ie=i(A(),te()),ae=i(j(),ne()),oe=localStorage.getItem(`iconMosaic.blueprint`),se=oe===null||oe===`true`,N=n.getContext(`webgl`,{antialias:!0});N.getExtension(`OES_standard_derivatives`);function ce(e,t){let n=N.createShader(e);if(N.shaderSource(n,t),N.compileShader(n),!N.getShaderParameter(n,N.COMPILE_STATUS))throw Error(N.getShaderInfoLog(n));return n}var le=`
  attribute vec3 aPosition;
  attribute vec3 aNormal;
  attribute vec3 aColor;
  attribute float aIsGreen;
  attribute float aFlowCoord;
  // The world-space arc length of whichever flow path this vertex was
  // assigned to (aFlowCoord's normalizing masterTotalLen, carried through
  // unnormalized) — lets the fragment shader convert the tail/core reach
  // back out of aFlowCoord's per-path-normalized space into an absolute
  // distance, so their real lengths stay the same regardless of how long
  // the specific arrow is. See recomputeModelFlowCoords/MODEL_FLOW_REFERENCE_LENGTH.
  attribute float aFlowPathLen;
  // Which technical-fill pattern (if any) this vertex's face uses: 0 = none,
  // 1 = hatch lines, 2 = dots, 3 = plus marks — see materialFillPatternId,
  // which maps a Blender material name to one of these. A single float
  // (rather than a separate boolean per pattern) keeps this to one
  // attribute/buffer regardless of how many fill patterns exist.
  attribute float aFillPattern;
  uniform mat4 uModelView;
  uniform mat4 uProjection;
  varying vec3 vNormal;
  varying vec3 vColor;
  varying float vIsGreen;
  varying float vFlowCoord;
  varying float vFlowPathLen;
  varying vec3 vPosition;
  varying float vFillPattern;
  void main() {
    gl_Position = uProjection * uModelView * vec4(aPosition, 1.0);
    // Object-space normal (no model rotation applied) so the light stays
    // fixed relative to the model instead of the camera as it's dragged.
    vNormal = aNormal;
    vColor = aColor;
    vIsGreen = aIsGreen;
    vFlowCoord = aFlowCoord;
    vFlowPathLen = aFlowPathLen;
    // Object-space position, same reasoning as vNormal above: the fill
    // pattern it drives (see CUBE_FRAGMENT_SHADER) needs to stay fixed to
    // the model rather than swim as the camera orbits.
    vPosition = aPosition;
    vFillPattern = aFillPattern;
  }
`,ue=`
  #extension GL_OES_standard_derivatives : enable
  precision mediump float;
  varying vec3 vNormal;
  varying vec3 vColor;
  varying float vIsGreen;
  varying float vFlowCoord;
  varying float vFlowPathLen;
  varying vec3 vPosition;
  varying float vFillPattern;
  uniform vec3 uLightDir;
  uniform float uLightIntensity;
  uniform bool uBlueprint;
  uniform vec3 uBlueprintFillColor;
  uniform vec3 uBlueprintFillColorGreen;
  uniform bool uFlowActive;
  // uFlowWorldPos is a shared, ever-growing world-space distance at the
  // *reference* speed (see flowSpeedWorldPerMs in renderCubeFrame) — the
  // speed a MODEL_FLOW_REFERENCE_LENGTH-long (uFlowReferenceLength) arrow
  // actually travels at. flowPulseIntensity below scales it per-vertex by
  // sqrt(vFlowPathLen / uFlowReferenceLength) so longer arrows move faster
  // than shorter ones — not proportionally faster (that would make every
  // arrow's lap TIME constant again, i.e. back in sync), just enough that
  // long arrows read livelier while still drifting out of phase with short
  // ones over time. The scaled result is then wrapped by this vertex's own
  // vFlowPathLen to get *this* arrow's own 0-1 travel-loop progress, and
  // this arrow's other concurrent pulses (see uFlowPulseDensity below) are
  // spaced out from that using uFlowRange/uFlowPad — all per-vertex since
  // pulse count, speed, and lap time all depend on vFlowPathLen.
  uniform float uFlowWorldPos;
  uniform float uFlowReferenceLength;
  uniform float uFlowRange;
  uniform float uFlowPad;
  // Pulses-per-MODEL_FLOW_REFERENCE_LENGTH-of-path-length (see
  // FLOW_PULSE_FREQUENCY_MIN/flowPulseDensity in renderCubeFrame) —
  // multiplied by this vertex's own vFlowPathLen in flowPulseIntensity
  // below to get that specific arrow's own pulse count, so a longer arrow
  // carries proportionally more concurrent pulses instead of the same
  // handful stretched thin over more physical distance. GLSL ES 1.00 loops
  // need a constant upper bound, so MAX_FLOW_PULSES caps the loop and each
  // arrow's own computed count is checked with a dynamic break. Raised from
  // the old 8 (which matched FLOW_PULSE_FREQUENCY_MAX, but that's the
  // density baseline for a MODEL_FLOW_REFERENCE_LENGTH-long arrow, not a
  // ceiling on any specific arrow's own count — a ~29-unit arrow at the
  // default "Pulse frequency" already computes ~49) so long arrows keep
  // scaling instead of saturating well before the default density would
  // otherwise allow — dialed back down from a first pass at 64, which read
  // as too dense/costly on the longest arrows. Each extra unit here is
  // extra worst-case per-fragment cost (one more possible loop
  // iteration/exp() pair), so don't raise this far past what the longest
  // arrows actually need.
  const int MAX_FLOW_PULSES = 32;
  uniform float uFlowPulseDensity;
  uniform float uFlowSigma;
  uniform vec3 uFlowColor;
  uniform vec3 uFlowCoreColor;
  // Absolute world-space head/core/tail reach (not a fraction of any one
  // path's own length — see MODEL_FLOW_REFERENCE_LENGTH) so all three stay
  // the same physical size on every arrow regardless of how long it is drawn.
  uniform float uFlowHeadWorldSigma;
  uniform float uFlowCoreWorldSigma;
  uniform float uFlowTailWorldSigma;
  uniform float uFlowTailFalloffExponent;
  uniform bool uFlowTailVisible;
  uniform vec3 uHatchLineColor;
  uniform float uLineFrequency;
  uniform float uDotFrequency;
  uniform float uDotRadius;
  uniform float uPlusFrequency;
  uniform float uPlusArmHalf;
  uniform float uPlusThickness;

  // Shared by all three fill patterns below (lines/dots/plus): projects
  // object-space position onto the two axes spanning the face (dropping
  // whichever axis the normal points along), sampled in object space so the
  // pattern stays put on the face as the model rotates instead of swimming
  // (screen-space would be simpler but reads as "wrong" the moment the
  // camera moves) — and so spacing is consistent regardless of which cube
  // face, or which arbitrary custom-model face, is flagged.
  vec2 fillPatternUV(vec3 pos, vec3 normal) {
    vec3 an = abs(normal);
    if (an.x >= an.y && an.x >= an.z) return pos.yz;
    if (an.y >= an.x && an.y >= an.z) return pos.xz;
    return pos.xy;
  }

  // Edge thickness/softness shared by all three patterns, and the shared
  // anti-moire fallback: derived from the screen-space gradient of each
  // pattern's own "distance to feature" value rather than a fixed fraction
  // of the period, so every pattern renders at a constant ~1 device pixel
  // — matching the wireframe overlay (gl.LINES at the default 1px width) —
  // regardless of how the face is scaled/tilted/zoomed. Below
  // MIN_RESOLVED_PERIOD_PX screen pixels per period, the pattern has more
  // than one repeat per pixel — under-sampled, so a crisp per-fragment test
  // aliases into shimmering moire as the surface (or the camera orbiting
  // it) tilts the face toward grazing incidence, where foreshortening keeps
  // shrinking the on-screen period. Standard fix (used for procedural
  // grids/checkers under minification): once the period drops close to or
  // below this, fade to the pattern's flat average coverage instead of
  // trying to resolve individual features the pixel grid can't represent.
  const float FILL_EDGE_HALF_WIDTH_PX = 1.0;
  const float FILL_MIN_RESOLVED_PERIOD_PX = 3.0;
  const float FILL_ALIASED_PERIOD_PX = 1.0;

  // Diagonal hatch lines. Uses the exact gradient length (dFdx/dFdy
  // combined via Pythagoras) rather than fwidth's cheaper
  // abs(dFdx)+abs(dFdy) approximation — fwidth overestimates the gradient
  // except when the line runs exactly along the x or y screen axis, so it
  // was making the line's rendered width (and thus its antialiasing)
  // inconsistent — thinner/rougher-looking — at the diagonal angles most
  // hatch lines actually run at.
  float hatchLinesMask(vec3 pos, vec3 normal) {
    vec2 uv = fillPatternUV(pos, normal);
    float diag = (uv.x + uv.y) * uLineFrequency;
    float gradLen = length(vec2(dFdx(diag), dFdy(diag)));
    float phase = fract(diag);
    float distToLine = min(phase, 1.0 - phase) / max(gradLen, 1e-6);
    float crispLine = 1.0 - smoothstep(0.0, FILL_EDGE_HALF_WIDTH_PX, distToLine);
    float periodPx = 1.0 / max(gradLen, 1e-6);
    float coverage = clamp((2.0 * FILL_EDGE_HALF_WIDTH_PX) / max(periodPx, 1e-3), 0.0, 1.0);
    float resolved = smoothstep(FILL_ALIASED_PERIOD_PX, FILL_MIN_RESOLVED_PERIOD_PX, periodPx);
    return mix(coverage, crispLine, resolved);
  }

  // Small filled circles on a regular grid, one per uDotFrequency cell.
  // uDotRadius is a fraction of the cell period (so dot size scales with
  // spacing, like a real screen-printed dot pattern) rather than a fixed
  // size — user-adjustable via the "Dot size" slider.
  float dotsMask(vec3 pos, vec3 normal) {
    vec2 uv = fillPatternUV(pos, normal) * uDotFrequency;
    vec2 cell = fract(uv) - 0.5;
    float dist = length(cell);
    float gradLen = length(vec2(dFdx(dist), dFdy(dist)));
    float distPx = (dist - uDotRadius) / max(gradLen, 1e-6);
    float crispDot = 1.0 - smoothstep(-FILL_EDGE_HALF_WIDTH_PX, FILL_EDGE_HALF_WIDTH_PX, distPx);
    float periodPx = 1.0 / max(gradLen, 1e-6);
    float flatCoverage = clamp(3.14159265 * uDotRadius * uDotRadius, 0.0, 1.0);
    float resolved = smoothstep(FILL_ALIASED_PERIOD_PX, FILL_MIN_RESOLVED_PERIOD_PX, periodPx);
    return mix(flatCoverage, crispDot, resolved);
  }

  // Small "+" marks on a regular grid, one per uPlusFrequency cell — a
  // union of a horizontal and a vertical bar (a cheap box-distance cross,
  // not an exact Euclidean SDF, but sufficient at the thin scale these
  // render at). uPlusArmHalf/uPlusThickness are fractions of the cell
  // period, same reasoning as uDotRadius above — user-adjustable via the
  // "Plus size" slider (thickness follows arm length at a fixed ratio, see
  // PLUS_THICKNESS_RATIO in renderCubeFrame, so it keeps reading as a "+").
  float plusMask(vec3 pos, vec3 normal) {
    vec2 uv = fillPatternUV(pos, normal) * uPlusFrequency;
    vec2 cell = fract(uv) - 0.5;
    float distH = max(abs(cell.y) - uPlusThickness, abs(cell.x) - uPlusArmHalf);
    float distV = max(abs(cell.x) - uPlusThickness, abs(cell.y) - uPlusArmHalf);
    float dist = min(distH, distV);
    float gradLen = length(vec2(dFdx(dist), dFdy(dist)));
    float distPx = dist / max(gradLen, 1e-6);
    float crispPlus = 1.0 - smoothstep(-FILL_EDGE_HALF_WIDTH_PX, FILL_EDGE_HALF_WIDTH_PX, distPx);
    float periodPx = 1.0 / max(gradLen, 1e-6);
    float flatCoverage = clamp(8.0 * uPlusArmHalf * uPlusThickness - 4.0 * uPlusThickness * uPlusThickness, 0.0, 1.0);
    float resolved = smoothstep(FILL_ALIASED_PERIOD_PX, FILL_MIN_RESOLVED_PERIOD_PX, periodPx);
    return mix(flatCoverage, crispPlus, resolved);
  }
  // Traveling energy-pulse intensity along a user-drawn arrow, restricted to
  // green (flagged) parts that some arrow actually touches — driven by a 3D
  // arc-length coordinate (aFlowCoord). Vertices on a green part no arrow was
  // ever drawn on get a negative aFlowCoord (see recomputeModelFlowCoords) so
  // they never light up, rather than defaulting to 0 and falsely flashing
  // whenever the pulse happens to pass near the start of some other part's
  // arrow.
  //
  // Comet shape rather than a symmetric Gaussian band: d>0 is ahead of the
  // pulse center in the direction of travel (increasing vFlowCoord, same
  // direction uFlowPulseCenter sweeps over time) — the comet's bright head,
  // narrow and fixed like the tail/core below, so it cuts off sharply just
  // past center. d<0 is behind — already passed, fading — so it uses
  // uFlowTailWorldSigma (user-adjustable "Tail length", an absolute
  // world-space distance via dArc below so it doesn't grow/shrink with this
  // specific arrow's own length) for its reach, and uFlowTailFalloffExponent
  // ("Tail falloff") for the curve's shape independent of that reach: 2.0
  // matches a plain Gaussian, higher stays near full brightness longer then
  // drops more sharply near the tail's end, lower behaves more like a thin
  // exponential streak. On top of both sits a second, much tighter "hot
  // core" lobe (uFlowCoreWorldSigma, "Core length" — symmetric, and, like
  // the head and tail, an absolute world-space size rather than a fraction
  // of this arrow's own length, so it doesn't grow/shrink with path length
  // either) adding extra brightness concentrated right at the head, so it
  // reads as a distinct bright point instead of just the front edge of a
  // flat-topped band.
  // 1.5 read fine back when the (now-removed) bloom pass pre-boosted
  // uFlowColor by up to 4x before blurring it — blur then spread that
  // extra brightness into an obviously bigger halo, so even a modest
  // additive nudge here translated into a dramatic glow change. Rendered
  // directly on the model with no blur, 1.5x on top of an already-bright
  // pulse barely moved the on-screen result, which is why widening "Core
  // length" only ever looked subtle after bloom was dropped. Raised to
  // compensate so the slider still has real range on its own.
  const float FLOW_COMET_CORE_BOOST = 4.5;
  // Every sigma below gets floored to cover at least this many screen
  // pixels — same fix as hatchLinesMask/dotsMask/plusMask above, applied to
  // the pulse instead of a fill pattern. vFlowCoord is a 0-1 fraction of
  // this specific arrow's own path length, so how many screen pixels one
  // unit of it spans isn't fixed — it shrinks the same way any world-space
  // length does when zoomed out, but *also* when the path's local direction
  // swings toward/away from the camera (orthographic projection collapses
  // length-along-view-direction to near nothing, independent of zoom — a
  // ground-parallel tube keeps its full length on screen from a bird's-eye
  // view, but a vertical one is now pointing straight at the camera). Once
  // a sigma that's a fixed WORLD size gets squeezed into a fraction of a
  // pixel by either effect, it can't be sampled correctly, which is exactly
  // the blocky/double-lobed look reported at steep angles and far zoom.
  // Widening the sigma here keeps the pulse resolvable to begin with.
  const float FLOW_MIN_SIGMA_PX = 1.0;
  // Returns (headTailIntensity, coreIntensity) separately rather than one
  // combined scalar — main() below colors them independently (uFlowColor
  // for the head/tail body, uFlowCoreColor for the hot core lobe), so the
  // core reads as a visibly distinct hot spot instead of just extra
  // brightness in the same color.
  vec2 flowPulseIntensity() {
    if (!(uBlueprint && uFlowActive && vIsGreen > 0.5 && vFlowCoord >= 0.0)) return vec2(0.0);
    float coordGradLen = length(vec2(dFdx(vFlowCoord), dFdy(vFlowCoord)));
    float minCoordSigma = coordGradLen * FLOW_MIN_SIGMA_PX;
    // minCoordSigma is in vFlowCoord's own 0-1-per-path units — scale it by
    // vFlowPathLen (same conversion dArc below uses) to floor tail/core
    // sigma in the world-space units they actually need to be in.
    float minWorldSigma = minCoordSigma * vFlowPathLen;
    // This arrow's own travel-loop progress. uFlowWorldPos is a shared
    // absolute world-space distance at the *reference* speed (see
    // flowSpeedWorldPerMs in renderCubeFrame); sqrt(lapLen/uFlowReferenceLength)
    // scales that up for longer arrows (down for shorter ones) so longer
    // arrows move faster in absolute terms, without scaling exactly enough
    // to keep every arrow's lap TIME equal — arrows still drift out of
    // phase with each other over time, which is intentional (see the file
    // header comment above "3D flow arrows"). The result is then wrapped by
    // *this* vertex's own vFlowPathLen to get this arrow's 0-1 progress.
    // GLSL's mod() always lands in [0, lapLen) for lapLen > 0, unlike JS's
    // %, so no separate handling for negative input is needed here.
    float lapLen = max(vFlowPathLen, 1e-6);
    float arrowWorldPos = uFlowWorldPos * sqrt(lapLen / uFlowReferenceLength);
    float basePulseCenter = -uFlowPad + mod(arrowWorldPos, lapLen) / lapLen * uFlowRange;
    // This arrow's own pulse count — longer arrows (bigger vFlowPathLen)
    // get proportionally more, see uFlowPulseDensity above. Floored to the
    // nearest whole pulse and never less than 1, so even a short arrow
    // always carries at least the primary pulse.
    int pulseCount = int(clamp(floor(uFlowPulseDensity * vFlowPathLen + 0.5), 1.0, float(MAX_FLOW_PULSES)));
    float spacing = uFlowRange / float(pulseCount);
    float totalBase = 0.0;
    float totalCore = 0.0;
    for (int i = 0; i < MAX_FLOW_PULSES; i++) {
      if (i >= pulseCount) break;
      // Extra pulses trail the primary one at even offsets around the
      // shared travel loop, each wrapped back into [-uFlowPad, uFlowRange -
      // uFlowPad) so they fade in/out at the loop's ends just like the
      // primary pulse instead of popping when an offset center wanders past
      // a boundary. GLSL's mod() (x - y*floor(x/y)) always lands in
      // [0, uFlowRange) for uFlowRange > 0, unlike JS's %, so no separate
      // handling for negative input is needed here.
      float shifted = basePulseCenter - float(i) * spacing + uFlowPad;
      float wrapped = mod(shifted, uFlowRange);
      float d = vFlowCoord - (wrapped - uFlowPad);
      // World-space distance from the pulse center — unlike d itself (a
      // fraction of this specific arrow's own length), this is the same
      // physical distance meaning on every arrow, which is what lets the
      // core lobe below stay a fixed size regardless of path length.
      float dArc = abs(d) * vFlowPathLen;
      float base;
      if (d > 0.0) {
        float sigma = max(uFlowHeadWorldSigma, minWorldSigma);
        base = exp(-(dArc * dArc) / (2.0 * sigma * sigma));
      } else {
        float tailSigma = max(max(uFlowTailWorldSigma, minWorldSigma), 1e-6);
        base = uFlowTailVisible ? exp(-0.5 * pow(dArc / tailSigma, uFlowTailFalloffExponent)) : 0.0;
      }
      float coreSigma = max(uFlowCoreWorldSigma, minWorldSigma);
      float core = exp(-(dArc * dArc) / (2.0 * coreSigma * coreSigma));
      totalBase += base;
      totalCore += core * FLOW_COMET_CORE_BOOST;
    }
    return vec2(totalBase, totalCore);
  }

  void main() {
    float diff = max(dot(normalize(vNormal), normalize(uLightDir)), 0.0) * uLightIntensity;
    float brightness = 0.2 + diff * 0.8;
    // Blueprint mode: ignore the material/cube color entirely and shade a
    // flat fill instead (navy, or green for green-material parts), dimmed
    // further so the wireframe overlay (drawn in a separate pass) reads as
    // the bright part of the look.
    vec3 base = uBlueprint ? (vIsGreen > 0.5 ? uBlueprintFillColorGreen : uBlueprintFillColor) : vColor;
    // Wider range than the old 0.3-0.6 (barely a 2x spread) so faces at
    // different angles to uLightDir read as clearly distinct shades instead
    // of nearly-uniform navy. Floor raised further (0.12 -> 0.3) so unlit
    // faces stay bright too, not just the lit ones.
    float shade = uBlueprint ? (0.3 + diff * 1.1) : brightness;
    vec3 color = base * shade;
    vec2 flowIntensity = flowPulseIntensity();
    color += uFlowColor * flowIntensity.x + uFlowCoreColor * flowIntensity.y;
    // Fill-pattern-flagged faces (see aFillPattern / materialFillPatternId)
    // get uHatchLineColor drawn on top of everything above in whichever
    // pattern their material selected, so it reads on top of blueprint
    // fill, shaded-mode lighting, and the flow glow alike.
    int fillPatternId = int(vFillPattern + 0.5);
    float fillMask = 0.0;
    if (fillPatternId == 1) fillMask = hatchLinesMask(vPosition, vNormal);
    else if (fillPatternId == 2) fillMask = dotsMask(vPosition, vNormal);
    else if (fillPatternId == 3) fillMask = plusMask(vPosition, vNormal);
    if (fillPatternId != 0) {
      color = mix(color, uHatchLineColor, fillMask);
    }
    gl_FragColor = vec4(color, 1.0);
  }
`,P=N.createProgram();if(N.attachShader(P,ce(N.VERTEX_SHADER,le)),N.attachShader(P,ce(N.FRAGMENT_SHADER,ue)),N.linkProgram(P),!N.getProgramParameter(P,N.LINK_STATUS))throw Error(N.getProgramInfoLog(P));var de=`
  attribute vec3 aLinePosition;
  attribute vec3 aLineColor;
  uniform mat4 uLineModelView;
  uniform mat4 uLineProjection;
  varying vec3 vLineColor;
  void main() {
    gl_Position = uLineProjection * uLineModelView * vec4(aLinePosition, 1.0);
    vLineColor = aLineColor;
  }
`,fe=`
  precision mediump float;
  varying vec3 vLineColor;
  uniform float uLineAlpha;
  void main() {
    gl_FragColor = vec4(vLineColor, uLineAlpha);
  }
`,F=N.createProgram();if(N.attachShader(F,ce(N.VERTEX_SHADER,de)),N.attachShader(F,ce(N.FRAGMENT_SHADER,fe)),N.linkProgram(F),!N.getProgramParameter(F,N.LINK_STATUS))throw Error(N.getProgramInfoLog(F));var pe={dark:{bg:[4/255,28/255,44/255],fill:[4/255,28/255,44/255],line:[124/255,134/255,142/255]},light:{bg:[1,1,1],fill:[244/255,246/255,247/255],line:[4/255,28/255,44/255]}},me=[68/255,214/255,44/255],he=[0,0,0],ge=[1,1,1],_e=[1,1,1],ve=Math.cos(25*Math.PI/180);function ye(e,t,n){let r=e.length/3,i=new Map,a=t.length/3;for(let o=0;o<a;o++){let a=t[o*3],s=t[o*3+1],c=t[o*3+2],l=e[a*3],u=e[a*3+1],d=e[a*3+2],f=e[s*3],p=e[s*3+1],m=e[s*3+2],h=e[c*3],g=e[c*3+1],_=e[c*3+2],v=f-l,y=p-u,b=m-d,x=h-l,S=g-u,C=_-d,w=y*C-b*S,T=b*x-v*C,E=v*S-y*x,D=Math.hypot(w,T,E)||1;w/=D,T/=D,E/=D;let ee=!!n[o],O=[[a,s],[s,c],[c,a]];for(let[e,t]of O){let n=e<t?e*r+t:t*r+e,a=i.get(n);if(!a)i.set(n,{i0:e,i1:t,nx:w,ny:T,nz:E,minDot:1,count:1,isGreen:ee});else{let e=a.nx*w+a.ny*T+a.nz*E;e<a.minDot&&(a.minDot=e),a.count++,ee&&(a.isGreen=!0)}}}let o=[],s=[];for(let{i0:t,i1:n,count:r,minDot:a,isGreen:c}of i.values())(r===1||a<ve)&&(o.push(e[t*3],e[t*3+1],e[t*3+2],e[n*3],e[n*3+1],e[n*3+2]),s.push(c));return{positions:new Float32Array(o),isGreen:s,colors:be(s,pe[O].line)}}function be(e,t){let n=new Float32Array(e.length*6);for(let r=0;r<e.length;r++){let i=e[r]?he:t,a=r*6;n[a]=i[0],n[a+1]=i[1],n[a+2]=i[2],n[a+3]=i[0],n[a+4]=i[1],n[a+5]=i[2]}return n}var xe=N.getAttribLocation(P,`aPosition`),Se=N.getAttribLocation(P,`aNormal`),Ce=N.getAttribLocation(P,`aColor`),we=N.getAttribLocation(P,`aIsGreen`),Te=N.getAttribLocation(P,`aFlowCoord`),Ee=N.getAttribLocation(P,`aFlowPathLen`),De=N.getAttribLocation(P,`aFillPattern`),Oe=N.getUniformLocation(P,`uModelView`),ke=N.getUniformLocation(P,`uProjection`),Ae=N.getUniformLocation(P,`uLightDir`),je=N.getUniformLocation(P,`uLightIntensity`),Me=N.getUniformLocation(P,`uBlueprint`),Ne=N.getUniformLocation(P,`uBlueprintFillColor`),Pe=N.getUniformLocation(P,`uBlueprintFillColorGreen`),Fe=N.getUniformLocation(P,`uFlowActive`),Ie=N.getUniformLocation(P,`uFlowWorldPos`),Le=N.getUniformLocation(P,`uFlowReferenceLength`),Re=N.getUniformLocation(P,`uFlowRange`),ze=N.getUniformLocation(P,`uFlowPad`),Be=N.getUniformLocation(P,`uFlowPulseDensity`),Ve=N.getUniformLocation(P,`uFlowSigma`),He=N.getUniformLocation(P,`uFlowColor`),Ue=N.getUniformLocation(P,`uFlowCoreColor`),We=N.getUniformLocation(P,`uFlowHeadWorldSigma`),Ge=N.getUniformLocation(P,`uFlowCoreWorldSigma`),Ke=N.getUniformLocation(P,`uFlowTailWorldSigma`),qe=N.getUniformLocation(P,`uFlowTailFalloffExponent`),Je=N.getUniformLocation(P,`uFlowTailVisible`),Ye=N.getUniformLocation(P,`uHatchLineColor`),Xe=N.getUniformLocation(P,`uLineFrequency`),Ze=N.getUniformLocation(P,`uDotFrequency`),Qe=N.getUniformLocation(P,`uDotRadius`),$e=N.getUniformLocation(P,`uPlusFrequency`),et=N.getUniformLocation(P,`uPlusArmHalf`),tt=N.getUniformLocation(P,`uPlusThickness`),I=N.getAttribLocation(F,`aLinePosition`),L=N.getAttribLocation(F,`aLineColor`),nt=N.getUniformLocation(F,`uLineModelView`),rt=N.getUniformLocation(F,`uLineProjection`),it=N.getUniformLocation(F,`uLineAlpha`);N.enable(N.DEPTH_TEST),N.clearColor(0,0,0,1);function at(e,t){let n=new Float32Array(16);for(let r=0;r<4;r++)for(let i=0;i<4;i++){let a=0;for(let n=0;n<4;n++)a+=e[n*4+i]*t[r*4+n];n[r*4+i]=a}return n}function ot(e,t,n,r,i,a){let o=1/(e-t),s=1/(n-r),c=1/(i-a);return new Float32Array([-2*o,0,0,0,0,-2*s,0,0,0,0,2*c,0,(e+t)*o,(r+n)*s,(a+i)*c,1])}function st(e){let t=Math.cos(e),n=Math.sin(e);return new Float32Array([1,0,0,0,0,t,n,0,0,-n,t,0,0,0,0,1])}function ct(e){let t=Math.cos(e),n=Math.sin(e);return new Float32Array([t,0,-n,0,0,1,0,0,n,0,t,0,0,0,0,1])}function lt(e,t,n){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,e,t,n,1])}function ut(e){return new Float32Array([e,0,0,0,0,e,0,0,0,0,e,0,0,0,0,1])}var dt=new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),R=5*Math.tan(Math.PI/8)/10,ft=R,z=R,pt=ot(-ft,ft,-z,z,.1,100);function mt(e){e>=1?(ft=R,z=R/e):(z=R,ft=R*e),pt=ot(-ft,ft,-z,z,.1,100)}var ht=1/3*.1,gt=-300,_t=300,vt=R*1.2,yt=0,bt=0,xt=0;function St(e){return Math.max(gt,Math.min(_t,e))}function Ct(){return[yt/100*vt,bt/100*vt,xt/100*vt]}var wt=-5,Tt=Math.PI/4,Et=Math.atan(1/Math.SQRT2),Dt=0,Ot=Math.PI/2,kt=Dt,At=!1,jt=.2,Mt=.1,Nt=0,Pt=0,Ft=document.querySelector(n.dataset.heroContentSelector||`.hero-content`),It=null,B=0,V=0,Lt=!1,Rt=2500,zt=null,Bt=0,Vt=0,H=e=>1-(1-e)**3,Ht=e=>1-(1-e)**2,Ut=e=>e<.5?2*e**2:1-(-2*e+2)**2/2,Wt=e=>-(Math.cos(Math.PI*e)-1)/2,Gt=e=>e<=0?0:e>=1?1:e<.5?2**(20*e-10)/2:(2-2**(-20*e+10))/2,Kt=180,qt=null,U=null,Jt=Et,Yt=Tt,Xt=100,Zt=0,Qt=Kt,$t=0,en=Kt,tn=H,nn=H,rn=!0;function an(e,t,n=Kt,r=!0,i=H,a=0,o=n,s=H,c=0){let l=y;U={rotX:Ot,rotY:kt,parX:B,parY:V,parTargetX:Nt,parTargetY:Pt,sizePercent:l*(1+a)},Jt=e,Yt=t,Xt=l,Zt=a,en=o,nn=s,rn=r,Qt=n,tn=i,$t=c,qt=performance.now()}var on=!1,sn=null,cn=0,ln=0,un=0,dn=H;function fn(e,t,n,r){kt=e,cn=e,ln=t,un=n,dn=r,sn=performance.now(),on=!0}var pn=!1,mn=!0,hn=!1;function gn(){n.style.cursor=mn?`default`:`grab`}gn();var _n=null;function vn(){_n===null&&(_n=requestAnimationFrame(()=>{_n=null,a(`cubeSize`,y),Z()}))}n.addEventListener(`pointerdown`,e=>{e.pointerType===`touch`&&(Ft&&e.clientY>=Ft.getBoundingClientRect().top||(It=e.pointerId,n.style.touchAction=`none`))}),window.addEventListener(`pointermove`,e=>{e.pointerType===`touch`&&e.pointerId!==It||yn(e)});function yn(e){if(Xr||Qr)return;let t=Math.max(-1,Math.min(1,e.clientX/window.innerWidth*2-1)),n=Math.max(-1,Math.min(1,e.clientY/window.innerHeight*2-1));Pt=t*jt,Nt=n*jt,Lt||(Lt=!0,Bt=B,Vt=V,zt=performance.now())}function bn(){if(zt!==null){let e=Math.min(1,(performance.now()-zt)/Rt),t=H(e);B=Bt+(Nt-Bt)*t,V=Vt+(Pt-Vt)*t,e>=1&&(zt=null)}else B+=(Nt-B)*Mt,V+=(Pt-V)*Mt}window.addEventListener(`pointerenter`,e=>{e.pointerType===`touch`&&e.pointerId!==It||yn(e)});{let e=e=>{e.pointerType===`touch`&&(e.pointerId===It&&(It=null),n.style.touchAction=``)};window.addEventListener(`pointerup`,e),window.addEventListener(`pointercancel`,e)}var xn=-Math.PI/2;function Sn(e){let t={},n=null;for(let r of e.split(`
`)){let e=r.trim();if(e.startsWith(`newmtl `))n=e.slice(7).trim(),t[n]=[1,1,1];else if(e.startsWith(`Kd `)&&n){let r=e.split(/\s+/);t[n]=[parseFloat(r[1]),parseFloat(r[2]),parseFloat(r[3])]}}return t}function Cn(e,t,n=1){let r=[],i=[],a=[],o=[],s=[],c=[],l=[],u=[],d=[],f=[],p=[1,1,1],m=!1,h=0,g=null,_=!1,v=new Map,y=[];function b(e,t,n){let r=g||`Object 1`,i=v.get(r);i||(i={minX:1/0,minY:1/0,minZ:1/0,maxX:-1/0,maxY:-1/0,maxZ:-1/0},v.set(r,i),y.push(r)),e<i.minX&&(i.minX=e),e>i.maxX&&(i.maxX=e),t<i.minY&&(i.minY=t),t>i.maxY&&(i.maxY=t),n<i.minZ&&(i.minZ=n),n>i.maxZ&&(i.maxZ=n)}let x=e.split(`
`);for(let e of x){let n=e.trim();if(n[0]===`v`&&n[1]===` `){let e=n.split(/\s+/);r.push([parseFloat(e[1]),parseFloat(e[2]),parseFloat(e[3])])}else if(n.startsWith(`vn `)){let e=n.split(/\s+/);i.push([parseFloat(e[1]),parseFloat(e[2]),parseFloat(e[3])])}else if(n[0]===`o`&&n[1]===` `)_=!0,g=n.slice(2).trim()||g;else if(n[0]===`g`&&n[1]===` `&&!_)g=n.slice(2).trim()||g;else if(n.startsWith(`usemtl `)){let e=n.slice(7).trim();p=t[e]||[1,1,1],m=ra(p[0]*255,p[1]*255,p[2]*255),h=ia(e)}else if(n[0]===`f`&&n[1]===` `){let e=n.split(/\s+/).slice(1).map(e=>{let[t,,n]=e.split(`/`),a=parseInt(t,10),o=a>0?a-1:r.length+a,s=null;if(n){let e=parseInt(n,10);s=e>0?e-1:i.length+e}return{vIdx:o,vnIdx:s}});for(let t=1;t<e.length-1;t++){let n=[e[0],e[t],e[t+1]],_=n.map(e=>r[e.vIdx]),v=n.map(e=>e.vnIdx===null?null:i[e.vnIdx]);if(v.some(e=>!e)){let e=_[1][0]-_[0][0],t=_[1][1]-_[0][1],n=_[1][2]-_[0][2],r=_[2][0]-_[0][0],i=_[2][1]-_[0][1],a=_[2][2]-_[0][2],o=t*a-n*i,s=n*r-e*a,c=e*i-t*r,l=Math.hypot(o,s,c)||1;o/=l,s/=l,c/=l,v=[[o,s,c],[o,s,c],[o,s,c]]}f.push(m);for(let e=0;e<3;e++)a.push(_[e][0],_[e][1],_[e][2]),o.push(v[e][0],v[e][1],v[e][2]),s.push(p[0],p[1],p[2]),c.push(+!!m),l.push(g||`Object 1`),u.push(h),d.push(n[e].vIdx),b(_[e][0],_[e][1],_[e][2])}}}if(a.length===0)return null;let S=xn;if(S!==0){let e=Math.cos(S),t=Math.sin(S);for(let n=0;n<a.length;n+=3){let r=a[n],i=a[n+2];a[n]=r*e+i*t,a[n+2]=-r*t+i*e;let s=o[n],c=o[n+2];o[n]=s*e+c*t,o[n+2]=-s*t+c*e}}let C=1/0,w=1/0,T=1/0,E=-1/0,D=-1/0,ee=-1/0;for(let e=0;e<a.length;e+=3){let t=a[e],n=a[e+1],r=a[e+2];t<C&&(C=t),t>E&&(E=t),n<w&&(w=n),n>D&&(D=n),r<T&&(T=r),r>ee&&(ee=r)}let O=(C+E)/2,k=w,A=(T+ee)/2,j=2/(Math.max(E-C,D-w,ee-T)||1)*10*n;for(let e=0;e<a.length;e+=3)a[e]=(a[e]-O)*j,a[e+1]=(a[e+1]-k)*j,a[e+2]=(a[e+2]-A)*j;let M=y.map(e=>{let t=v.get(e),n=(t.minX+t.maxX)/2,r=(t.minY+t.maxY)/2,i=(t.minZ+t.maxZ)/2;if(S!==0){let e=Math.cos(S),t=Math.sin(S),r=n*e+i*t,a=-n*t+i*e;n=r,i=a}let a=Math.hypot(t.maxX-t.minX,t.maxY-t.minY,t.maxZ-t.minZ)*j,o=1/0,s=-1/0,c=1/0,l=-1/0;for(let e of[t.minX,t.maxX])for(let n of[t.minZ,t.maxZ]){let t=e,r=n;if(S!==0){let i=Math.cos(S),a=Math.sin(S);t=e*i+n*a,r=-e*a+n*i}t<o&&(o=t),t>s&&(s=t),r<c&&(c=r),r>l&&(l=r)}let u={minX:(o-O)*j,maxX:(s-O)*j,minY:(t.minY-k)*j,maxY:(t.maxY-k)*j,minZ:(c-A)*j,maxZ:(l-A)*j};return{name:e,center:[(n-O)*j,(r-k)*j,(i-A)*j],size:a,bounds:u}}),te=new Map(y.map((e,t)=>[e,t])),ne=l.map(e=>te.get(e)),re=new Float32Array(r.length*3);for(let e=0;e<r.length;e++){let[t,n,i]=r[e];if(S!==0){let e=Math.cos(S),n=Math.sin(S),r=t*e+i*n,a=-t*n+i*e;t=r,i=a}re[e*3]=(t-O)*j,re[e*3+1]=(n-k)*j,re[e*3+2]=(i-A)*j}let ie=ye(re,new Uint32Array(d),f);return{positions:new Float32Array(a),normals:new Float32Array(o),colors:new Float32Array(s),isGreen:new Float32Array(c),objectIndex:new Float32Array(ne),fillPattern:new Float32Array(u),linePositions:ie.positions,lineColors:ie.colors,lineIsGreen:ie.isGreen,hasMaterials:Object.keys(t).length>0,objects:M}}var wn=N.createBuffer(),Tn=N.createBuffer(),En=N.createBuffer(),Dn=N.createBuffer(),On=N.createBuffer(),kn=N.createBuffer(),An=N.createBuffer(),jn=N.createBuffer(),Mn=N.createBuffer(),Nn=0,Pn=0,Fn=!1,In=``,Ln=[],Rn=[],W=[null,null,null],G=null,K=[0,0,0],q=null,zn=null,Bn={offsetX:-5.17360464543138,offsetY:0,offsetZ:20.631551421416827,sizePercent:17.345816691087055};function Vn(e){S(e.sizePercent),yt=e.offsetX,bt=e.offsetY,xt=e.offsetZ,Z()}function Hn(){K=[0,0,0],J=1,Y=[0,0,0],Kn=0,X=null,qn=!0}function Un(){zn&&(G!==null&&Cr(),Hn(),Vn(zn))}var Wn=!1,Gn=t,J=1,Y=[0,0,0],Kn=0,X=null,qn=!0,Jn=15,Yn=9,Xn=4,Zn=4.65,Qn=.05,$n=.01,er=.25,tr=.01,nr=5,rr=720,ir=.28,ar=0;function or(){ar=window.innerWidth<=rr?z*ir:0}function sr(){return{spaceHeld:At,photoMode:pn,rotationDisabled:mn,modelOffsetX:yt,modelOffsetY:bt,customModelReady:Fn,cubeModelStatus:In,customModelObjectNames:Rn.map(e=>e.name),cameraTargetSlots:W,cameraTargetActiveIndex:G,showCameraTargetBoxes:Wn,hasDefaultCameraView:!!zn,editingDefaultView:hn,modelFlowArrowCount:Q.length,selectedFlowArrowIndex:$r,modelFlowDrawMode:Xr,modelFlowSelectMode:Qr,showModelFlowArrow:ei,selectedFlowArrowObjects:(()=>{let e=$r===null?null:Q[$r];return!e||e.touchedObjectIndices.length<=1?[]:e.touchedObjectIndices.map(t=>({index:t,name:Rn[t]?.name??`Object ${t+1}`,enabled:e.enabledObjectIndices.includes(t)}))})(),selectedFlowArrowReversed:!!($r!==null&&Q[$r]?.reversed)}}function cr(){let[e,t,n]=Vi(),r=ht*b*J;return r>0?[-e/r,-t/r,-n/r]:[0,0,0]}function lr(e){let t=W[e],n=t?Rn.find(e=>e.name===t):null,r=n?n.center:[0,0,0],i=1;if(n&&n.bounds){let{minX:e,maxX:t,minY:r,maxY:a,minZ:o,maxZ:s}=n.bounds,[c,l,u]=n.center,d=1/0,f=-1/0;for(let n of[e,t])for(let e of[r,a])for(let t of[o,s]){let r=Ii(Li([n-c,e-l,t-u],Tt),Et);r[1]<d&&(d=r[1]),r[1]>f&&(f=r[1])}let p=f-d;if(p>1e-6){let e=1-2*er,t=Zr===null?b:Zr/100;i=Math.max(tr,Math.min(nr,e*2*z/(p*ht*t)))}}return{center:r,zoomGoal:i}}function ur(e){W[e]&&(q!==null&&(clearTimeout(q),q=null),dr=!1,G===null&&(K=cr(),Y=[0,0,0],X=null),G=e,Z())}var dr=!1,fr=null,pr=[0,0,0],mr=[0,0,0],hr=1,gr=1,_r=Kt,vr=H,yr=Kt,br=H,xr=0;function Sr(e,t,n,r=t,i=n,a=0){if(!W[e])return;pr=cr(),hr=J;let o=lr(e);mr=o.center,gr=o.zoomGoal,K=[...pr],Y=[0,0,0],X=null,G=e,_r=t,vr=n,yr=r,br=i,xr=a,fr=performance.now(),dr=!0,Z()}function Cr(){q!==null&&(clearTimeout(q),q=null),dr=!1,G=null,Z()}function Z(){let e=sr();Ln.forEach(t=>t(e))}var wr=null,Tr=null,Er=null;function Dr(e,t,n,r=[null,null,null]){if(!e){Fn=!1,In=`Couldn't find any faces in ${t}`,Z();return}N.bindBuffer(N.ARRAY_BUFFER,wn),N.bufferData(N.ARRAY_BUFFER,e.positions,N.STATIC_DRAW),N.bindBuffer(N.ARRAY_BUFFER,Tn),N.bufferData(N.ARRAY_BUFFER,e.normals,N.STATIC_DRAW),N.bindBuffer(N.ARRAY_BUFFER,En),N.bufferData(N.ARRAY_BUFFER,e.colors,N.STATIC_DRAW),N.bindBuffer(N.ARRAY_BUFFER,Dn),N.bufferData(N.ARRAY_BUFFER,e.isGreen,N.STATIC_DRAW),N.bindBuffer(N.ARRAY_BUFFER,On),N.bufferData(N.ARRAY_BUFFER,e.fillPattern,N.STATIC_DRAW),Nn=e.positions.length/3,N.bindBuffer(N.ARRAY_BUFFER,jn),N.bufferData(N.ARRAY_BUFFER,e.linePositions,N.STATIC_DRAW),N.bindBuffer(N.ARRAY_BUFFER,Mn),N.bufferData(N.ARRAY_BUFFER,e.lineColors,N.STATIC_DRAW),Pn=e.linePositions.length/3,wr=e.positions,Tr=e.isGreen,Er=e.objectIndex,e.linePositions,e.lineIsGreen,Rn=e.objects,W=[...r],G=null,K=[0,0,0],J=1,Y=[0,0,0],Kn=0,X=null,qn=!0;let i=[],a=[];for(let t=0;t<e.isGreen.length;t+=3)if(e.isGreen[t]){let n=t*3;for(let t=0;t<9;t++)i.push(e.positions[n+t]);a.push(e.objectIndex[t])}new Float32Array(i),Fn=!0,S(100);let o=Nn/3;In=e.hasMaterials?`${t} (${o} tris, colors from ${n})`:`${t} (${o} tris, no materials found)`,Z()}var Or=1e3,kr=2e3,Ar=2e3,jr=5e3,Mr=3e3,Nr=2e3,Pr=5e3-Ar;Pr+Math.max(jr,5e3);var Fr=1e4,Ir=-30;async function Lr(){try{let[e,t]=await Promise.all([fetch(`/models/ngen_assets.obj`).then(e=>e.text()),fetch(`/models/ngen_assets.mtl`).then(e=>e.text())]);Dr(Cn(e,Sn(t),8),`ngen_assets.obj`,`ngen_assets.mtl`,[`1-For_Home`,`2-For_Business`,`3-For_Investors`]),zn=Bn,Vn(zn),fn(Tt+Ir*Math.PI/180,Tt,Fr,Wt),an(Et,kt,kr,!1,Gt,.5,5e3,Ht,Or),q=setTimeout(()=>Sr(0,jr,Ut,Mr,Ut,Nr),Pr),qi()}catch(e){console.error(e)}}var Rr=`iconMosaic.modelFlowPath`,zr=[{points:[[-33.67333602905275,.6334688513144009,-5.099300492059335],[-33.673336029052734,.6339370829337714,-5.179315505773158],[-33.673336029052734,.10385314082481045,-5.178646390804898],[-34.33642197886703,.09333333373069763,-5.17300515430707],[-34.336034799862055,.09333333373069763,-6.6424453440926]],touchedObjectIndices:[502],enabledObjectIndices:[502],sourceOffset:0,masterTotalLen:2.742734374529774},{points:[[-34.833863038597045,.09333333373069763,-4.990590645997877],[-33.68693837931779,.09333333373069763,-4.9914932159016985],[-33.67333602905275,.4826526655058707,-4.993658371678258]],touchedObjectIndices:[471],enabledObjectIndices:[471],sourceOffset:0,masterTotalLen:1.536487915533214},{points:[[-33.78354617495815,.2800000011920787,-4.123070418601841],[-33.67767859420686,.2800000011920787,-4.124411198391016],[-33.67333602905274,.6302302259155255,-4.124307431025137],[-33.67333602905274,.6295758712951454,-4.878244125480762]],touchedObjectIndices:[454],enabledObjectIndices:[454],sourceOffset:0,masterTotalLen:1.2100702102757512},{points:[[-33.32420476002098,1.2577114491708272,-5.285326013957132],[-33.32296006593586,1.2583338584281734,-4.995782500557958],[-33.657797496354306,1.090916293413585,-4.994099790208907],[-33.669162634621344,1.0733935068405174,-4.986517049287329],[-33.67333221435546,.7885513701981637,-4.994376147461708]],touchedObjectIndices:[457],enabledObjectIndices:[457],sourceOffset:0,masterTotalLen:.9711104332982854},{points:[[-3.545370438687139,.0889253318309784,-4.02120909084195],[-2.3039824711500287,.0889253318309926,-4.022964701175553],[-2.307952797638868,.0889253318309926,-5.128014704598215],[-1.6991531674456155,.0889253318309784,-5.127725425432118],[-1.6936733722686768,.4806781991282705,-5.130003931825662]],touchedObjectIndices:[466],enabledObjectIndices:[466],sourceOffset:0,masterTotalLen:3.3470438599599985},{points:[[-1.2446098828058325,2.8791640714992326,-6.6464924812316895],[-1.2434510702200967,2.9714566618539493,-6.646492481231682],[-1.2362821235638108,2.989035367965684,-6.5128454175166155],[-1.2455523082880262,1.9655008783336427,-6.499578475952148],[-1.243214283300901,1.9481827020645284,-5.137658892077695],[-1.560959332080536,1.9481827020645284,-5.139350339433168],[-1.5664444792017136,2.0933260917663716,-5.129035598032328],[-1.6844905121384706,2.0933260917663574,-5.132020131464714],[-1.693333387374878,.7782431359708681,-5.130084734400263]],touchedObjectIndices:[272,274],enabledObjectIndices:[272,274],sourceOffset:0,masterTotalLen:4.509542884635783},{points:[[-.5052271805852371,.0889253318309784,-4.183513742795114],[-.5110608126283864,.0889253318309784,-4.026547851175067],[-.9624689833783862,.0889253318309784,-4.024944936016851]],touchedObjectIndices:[456],enabledObjectIndices:[456],sourceOffset:0,masterTotalLen:3.568297247388635},{points:[[-.9593934528637931,.0889253318309926,-4.189260081557322],[-.9624689833783862,.0889253318309784,-4.024944936016851]],touchedObjectIndices:[456],enabledObjectIndices:[456],sourceOffset:.6084852742361518,masterTotalLen:3.568297247388635},{points:[[-.9624689833783862,.0889253318309784,-4.024944936016851],[-1.4159273931998086,.08892533183096418,-4.030957359749507]],touchedObjectIndices:[456],enabledObjectIndices:[456],sourceOffset:.6084852742361518,masterTotalLen:3.568297247388635},{points:[[-1.4036374297271124,.0889253318309784,-4.187952105857235],[-1.4159273931998086,.08892533183096418,-4.030957359749507]],touchedObjectIndices:[456],enabledObjectIndices:[456],sourceOffset:1.0619835417928363,masterTotalLen:3.568297247388635},{points:[[-1.4159273931998086,.08892533183096418,-4.030957359749507],[-2.0966853166633825,.0889253318309784,-4.024516778344889],[-2.1049183626496557,.0889253318309784,-5.049078083369096],[-1.6952627329553849,.08892533183096418,-5.051043516499163],[-1.693673372268691,.48014507145907004,-5.057147795352122]],touchedObjectIndices:[456],enabledObjectIndices:[456],sourceOffset:1.0619835417928363,masterTotalLen:3.568297247388635},{points:[[-3.014371155879864,.08868800103665819,-8.063377333100462],[-2.508953709940149,.08868800103662977,-8.062679889324755],[-2.5107751005562715,.08868800103662977,-6.641391648079718]],touchedObjectIndices:[519],enabledObjectIndices:[519],sourceOffset:0,masterTotalLen:4.561781532348327},{points:[[-2.5107751005562715,.08868800103662977,-6.641391648079718],[-3.019299699296553,.08868800103664398,-6.637623239598327]],touchedObjectIndices:[519],enabledObjectIndices:[519],sourceOffset:1.9267073354602382,masterTotalLen:4.561781532348327},{points:[[-2.5107751005562715,.08868800103662977,-6.641391648079718],[-2.512596986987414,.08868800103664398,-5.20532039295415]],touchedObjectIndices:[519],enabledObjectIndices:[519],sourceOffset:1.9267073354602382,masterTotalLen:4.561781532348327},{points:[[-2.512596986987414,.08868800103664398,-5.20532039295415],[-3.0151256508047664,.08868800103664398,-5.209381583373798]],touchedObjectIndices:[519],enabledObjectIndices:[519],sourceOffset:3.362779746262735,masterTotalLen:4.561781532348327},{points:[[-2.512596986987414,.08868800103664398,-5.20532039295415],[-1.701865099401573,.08868800103662977,-5.2064795508370025],[-1.6936733722686483,.47687063124877227,-5.20658818051011]],touchedObjectIndices:[519],enabledObjectIndices:[519],sourceOffset:3.362779746262735,masterTotalLen:4.561781532348327},{points:[[56.64267714550567,4.968986209546813,-12.126598031036224],[27.523574865830284,4.967351936525006,-12.131152901015355]],touchedObjectIndices:[255,526],enabledObjectIndices:[255,526],sourceOffset:0,masterTotalLen:29.119102681777225},{points:[[56.639257384320956,4.972883906455081,-14.18441350946614],[27.683999898248885,4.948396873634977,-14.176995998733673]],touchedObjectIndices:[252,525],enabledObjectIndices:[252,525],sourceOffset:0,masterTotalLen:28.955268790307827},{points:[[56.59511154597794,3.960689692842152,-14.175570766584428],[27.712595036696314,3.938394158777214,-14.169512149511888]],touchedObjectIndices:[253,523],enabledObjectIndices:[253,523],sourceOffset:0,masterTotalLen:28.882525750124515},{points:[[56.62485130331089,2.9628874175188002,-14.176398252495716],[27.615066068317844,2.947036058732351,-14.171930787410304]],touchedObjectIndices:[254,521],enabledObjectIndices:[254,521],sourceOffset:0,masterTotalLen:29.009789909688077},{points:[[56.60939563623336,3.9604482056058146,-12.120713853240204],[27.662967160182006,3.9488361380687707,-12.122798679489222]],touchedObjectIndices:[256,524],enabledObjectIndices:[256,524],sourceOffset:0,masterTotalLen:28.946430880261726},{points:[[56.580646683000566,2.9630913259489375,-12.125700416702443],[27.589015513606,2.957438173277069,-12.126803350970505]],touchedObjectIndices:[257,522],enabledObjectIndices:[257,522],sourceOffset:0,masterTotalLen:28.99163174153552},{points:[[26.702889461814053,.48938447734039414,-13.156804209939772],[26.629931553299897,.10012843737730037,-13.15624756887133],[26.099485969574538,.0948086678981852,-13.162904139678389],[26.10098189159153,.094808667898171,-10.946355917461183],[26.627926738888952,.0948086678981852,-10.955670015562845]],touchedObjectIndices:[469],enabledObjectIndices:[469],sourceOffset:0,masterTotalLen:3.6701245394262725},{points:[[26.63094535254865,.094808667898171,-10.837164729838705],[25.556571453468763,.0948086678981781,-10.835559514474838],[25.551508571763442,.0948086678981852,-9.670081876977626]],touchedObjectIndices:[520],enabledObjectIndices:[520],sourceOffset:0,masterTotalLen:10.90267950043367},{points:[[25.551508571763442,.0948086678981852,-9.670081876977626],[25.552221611326566,.0948086678981781,-9.315084216802937]],touchedObjectIndices:[520],enabledObjectIndices:[520],sourceOffset:2.239863732376519,masterTotalLen:10.90267950043367},{points:[[25.551508571763442,.0948086678981852,-9.670081876977626],[33.844104082957955,.0948086678981852,-9.71162043695659],[33.83814635565336,.0948086678981781,-9.34155216874678]],touchedObjectIndices:[520],enabledObjectIndices:[520],sourceOffset:2.239863732376519,masterTotalLen:10.90267950043367},{points:[[33.84013891067453,.0948086678981781,-8.612637530990646],[33.84052216104054,.094808667898171,-7.923875042596943]],touchedObjectIndices:[531],enabledObjectIndices:[531],sourceOffset:0,masterTotalLen:.6887625950203233},{points:[[33.843547026275836,.0948086678981852,-7.177972647955603],[33.839323405959924,.0948086678981852,-6.512914662659418]],touchedObjectIndices:[530],enabledObjectIndices:[530],sourceOffset:0,masterTotalLen:.665071396749848},{points:[[33.5561593599526,.09336933493614197,-6.097066672414521],[33.00008397068226,.09336933493613486,-6.0959972397190505],[33.001008896437554,.09336933493612776,-5.970430913361219],[32.77604210412262,.12071466445922852,-5.966940748732361]],touchedObjectIndices:[430],enabledObjectIndices:[430],sourceOffset:0,masterTotalLen:.9082956727126772},{points:[[33.47422256200509,.09336933493612776,-6.176403052918243],[33.0030388426357,.09336933493614197,-6.175757784827053],[33.003963050551604,.09336933493613486,-6.325207934479132],[32.76859981158998,.12071466445922852,-6.320114847679658]],touchedObjectIndices:[429],enabledObjectIndices:[429],sourceOffset:0,masterTotalLen:.8576383516970716},{points:[[33.47595932257196,.09336933493614197,-7.5093493894576255],[33.004845213307625,.09336933493614197,-7.508294379635415],[33.0055499068346,.09336933493613486,-7.378371671184648],[32.774475361240874,.12071466445922852,-7.374453837635869]],touchedObjectIndices:[361],enabledObjectIndices:[361],sourceOffset:0,masterTotalLen:.8337598320828127},{points:[[33.47743926387794,.09336933493613486,-7.587222117028423],[33.0035173938905,.09336933493614197,-7.5791694568789945],[33.00440896881824,.09336933493613486,-7.726269631507278],[32.770306080176695,.12071466445922852,-7.731668607332408]],touchedObjectIndices:[360],enabledObjectIndices:[360],sourceOffset:0,masterTotalLen:.856849551531731},{points:[[33.476681201714925,.09336933493614197,-9.009880168323981],[33.004765023574926,.09336933493614197,-9.011691697654651],[33.00420764408614,.09336933493613486,-9.152100624320573],[32.77127923318871,.12071466445922852,-9.154369000953528]],touchedObjectIndices:[383],enabledObjectIndices:[383],sourceOffset:0,masterTotalLen:.8468687192852006},{points:[[33.47899528138069,.09336933493614197,-8.935319304603224],[32.99287904076515,.09336933493614907,-8.934994651040851],[32.996545069571305,.09336933493613486,-8.804234025750223],[32.77299155397665,.12071466445922852,-8.802572480073657]],touchedObjectIndices:[384],enabledObjectIndices:[384],sourceOffset:0,masterTotalLen:.8421542462567777},{points:[[25.555624676521393,.0948086678981852,-8.576366331515706],[25.55873393993857,.094808667898171,-7.917995535178209]],touchedObjectIndices:[528],enabledObjectIndices:[528],sourceOffset:0,masterTotalLen:.6583781382982482},{points:[[25.550015806157173,.0948086678981781,-7.17873453005429],[25.54999844507648,.0948086678981852,-6.537975261961543]],touchedObjectIndices:[529],enabledObjectIndices:[529],sourceOffset:0,masterTotalLen:.6407592683279415},{points:[[25.841287509677116,.09336933493614197,-8.989760054410024],[26.40927208512327,.09336933493614907,-8.984641874082614],[26.399043672361934,.09336933493613486,-9.122077792282537],[26.627899324151944,.12071466445923562,-9.122611424539093]],touchedObjectIndices:[337],enabledObjectIndices:[337],sourceOffset:0,masterTotalLen:.9363078317197809},{points:[[25.844260286948394,.09336933493615618,-8.911679003098609],[26.395098837335013,.09336933493614197,-8.912205403765018],[26.398594247163405,.09336933493614907,-8.767530111917507],[26.611770332433146,.12071466445922141,-8.76732241082537]],touchedObjectIndices:[338],enabledObjectIndices:[338],sourceOffset:0,masterTotalLen:.9104792141428489},{points:[[25.86863690588295,.09336933493614907,-7.592943547379436],[26.403673552833915,.09336933493615618,-7.59277892855316],[26.401491278293747,.09336933493615618,-7.730870732635107],[26.622202535407236,.12071466445922852,-7.725840801850269]],touchedObjectIndices:[314],enabledObjectIndices:[314],sourceOffset:0,masterTotalLen:.8956013911896795},{points:[[25.862139697855902,.09336933493613486,-7.5224858506586205],[26.406818854032085,.09336933493615618,-7.521693768594748],[26.408680856399595,.09336933493614907,-7.377864186292422],[26.634794684842756,.12071466445923562,-7.374748403467135]],touchedObjectIndices:[315],enabledObjectIndices:[315],sourceOffset:0,masterTotalLen:.9163040229577386},{points:[[25.868928816897714,.09336933493614907,-6.1796607497829],[26.399127203696043,.09336933493614197,-6.188344970234791],[26.402831673390146,.09336933493614907,-6.312434377158447],[26.634555151441567,.12071466445923562,-6.312567973143766]],touchedObjectIndices:[406],enabledObjectIndices:[406],sourceOffset:0,masterTotalLen:.8877456198313817},{points:[[25.87837914132087,.09336933493614197,-6.1052600381899085],[26.397076042267102,.09336933493614907,-6.104628375877571],[26.405110454385312,.09336933493614907,-5.9627140522099396],[26.622408764318163,.12071466445924273,-5.958620580626187]],touchedObjectIndices:[407],enabledObjectIndices:[407],sourceOffset:0,masterTotalLen:.879889262497587}],Br=.15,Vr=3,Hr=.12,Ur=-1,Wr=[.2,.45,.95],Gr=[1,0,0],Kr=3,qr=.75,Jr=3e3,Yr=13,Xr=!1,Zr=null,Qr=!1,Q=[],$r=null,ei=!1,ti=!0,ni=N.createBuffer(),ri=5,ii=20,ai=[1,.95,.55],oi=[.72,.52,.04],si=N.createBuffer();function ci(e,t,n,r,i,a){let o=t/2,s=n/2,c=r/o,l=r/s,[u,d,f]=e,p=[];for(let e=0;e<ii;e++){let t=e/ii*Math.PI*2,n=(e+1)/ii*Math.PI*2;p.push(u,d,f,...i,u+Math.cos(t)*c,d+Math.sin(t)*l,f,...a,u+Math.cos(n)*c,d+Math.sin(n)*l,f,...a)}return p}function li(e,t,n,r){return new Float32Array(ci(e,t,n,r,ai,oi))}function ui(e,t,n,r,i,a,o){let s=[];for(let c of e){let e=t[0]*c[0]+t[4]*c[1]+t[8]*c[2]+t[12],l=t[1]*c[0]+t[5]*c[1]+t[9]*c[2]+t[13],u=t[2]*c[0]+t[6]*c[1]+t[10]*c[2]+t[14];s.push(...ci([e,l,u],n,r,i,a,o))}return new Float32Array(s)}function di(e,t,r,i,a){if(e.length===0)return;let o=ui(e,t,n.width,n.height,r,i,a);N.bindBuffer(N.ARRAY_BUFFER,wi),N.bufferData(N.ARRAY_BUFFER,o,N.DYNAMIC_DRAW),N.vertexAttribPointer(I,3,N.FLOAT,!1,24,0),N.vertexAttribPointer(L,3,N.FLOAT,!1,24,12),N.drawArrays(N.TRIANGLES,0,o.length/6)}var fi=12,pi=[1,1,1],mi=[.55,.55,.55],hi=fi*1.35,gi=[1,.92,.3],_i=[.75,.6,.05],vi=hi,yi=[1,.55,.1],bi=[.65,.3,.02],xi=hi,Si=[.3,.55,1],Ci=[.1,.25,.7],wi=N.createBuffer(),Ti=[1,.85,.15],Ei=1.25,Di=6,Oi=5,ki=N.createBuffer();N.createBuffer(),N.createBuffer();function Ai(e,t,n,r,i,a,o,s){let c=r/2,l=i/2,u=e=>[n[0]*e[0]+n[4]*e[1]+n[8]*e[2]+n[12],n[1]*e[0]+n[5]*e[1]+n[9]*e[2]+n[13],n[2]*e[0]+n[6]*e[1]+n[10]*e[2]+n[14]],d=u(e),f=u(t),p=(f[0]-d[0])*c,m=(f[1]-d[1])*l,h=Math.hypot(p,m)||1;p/=h,m/=h;let g=-m*a/c,_=p*a/l,v=[],y=o+s,b=Math.ceil(h/y);for(let e=0;e<b;e++){let t=e*y;if(t>=h)break;let n=Math.min(t+o,h),r=t/h,i=n/h,a=d[0]+(f[0]-d[0])*r,s=d[1]+(f[1]-d[1])*r,c=d[2]+(f[2]-d[2])*r,l=d[0]+(f[0]-d[0])*i,u=d[1]+(f[1]-d[1])*i,p=d[2]+(f[2]-d[2])*i;v.push(a-g,s-_,c,l-g,u-_,p,a+g,s+_,c,a+g,s+_,c,l-g,u-_,p,l+g,u+_,p)}return new Float32Array(v)}var ji=4,Mi=2.2,Ni=10;function Pi(e,t,n,r,i,a){let o=(n[0]-t[0])*r,s=(n[1]-t[1])*i,c=Math.hypot(o,s)||1;o/=c,s/=c;let l=-s*a,u=o*a,d=-o*a,f=-s*a;for(let n=0;n<Ni;n++){let a=Math.PI*n/Ni,o=Math.PI*(n+1)/Ni,s=l*Math.cos(a)+d*Math.sin(a),c=u*Math.cos(a)+f*Math.sin(a),p=l*Math.cos(o)+d*Math.sin(o),m=u*Math.cos(o)+f*Math.sin(o);e.push(t[0],t[1],t[2],t[0]+s/r,t[1]+c/i,t[2],t[0]+p/r,t[1]+m/i,t[2])}}function Fi(e,t,n,r,i){let a=n/2,o=r/2,s=i*ji,c=i*Mi,l=[];for(let n of e){let e=n.map(e=>[t[0]*e[0]+t[4]*e[1]+t[8]*e[2]+t[12],t[1]*e[0]+t[5]*e[1]+t[9]*e[2]+t[13],t[2]*e[0]+t[6]*e[1]+t[10]*e[2]+t[14]]);e.length>=2&&Pi(l,e[0],e[1],a,o,i);for(let t=0;t<e.length-1;t++){let n=e[t],r=e[t+1],u=(r[0]-n[0])*a,d=(r[1]-n[1])*o,f=Math.hypot(u,d)||1;u/=f,d/=f;let p=-d*i/a,m=u*i/o,h=n[0]-p,g=n[1]-m,_=n[0]+p,v=n[1]+m,y=r[0]-p,b=r[1]-m,x=r[0]+p,S=r[1]+m;if(l.push(h,g,n[2],y,b,r[2],_,v,n[2],_,v,n[2],y,b,r[2],x,S,r[2]),t===e.length-2){let e=u*s/a,t=d*s/o,n=r[0]-e,i=r[1]-t,f=-d*c/a,p=u*c/o;l.push(r[0],r[1],r[2],n-f,i-p,r[2],n+f,i+p,r[2])}}}return new Float32Array(l)}function Ii(e,t){let n=Math.cos(t),r=Math.sin(t);return[e[0],e[1]*n-e[2]*r,e[1]*r+e[2]*n]}function Li(e,t){let n=Math.cos(t),r=Math.sin(t);return[e[0]*n+e[2]*r,e[1],-e[0]*r+e[2]*n]}function Ri(e,t,n,r,i=Jn,a=Yn){if(r<=0)return[e,t];let o=Math.sqrt(i),s=a/(2*o),c=e-n,l=t,u=o*Math.sqrt(s*s-1),d=-s*o+u,f=-s*o-u,p=(l-c*f)/(d-f),m=c-p,h=Math.exp(d*r),g=Math.exp(f*r),_=p*h+m*g,v=p*d*h+m*f*g;return[_+n,v]}function zi(e,t,n,r){return Ii(Li([e[0]*r,e[1]*r,e[2]*r],n),t)}function Bi(e,t,n){let r=zi(K,e,t,n);return[-r[0],-r[1]+ar]}function Vi(){return G!==null||!qn?[0,0,0]:Ct()}function Hi(e,t){let{points:n,cumLen:r}=e,i=1/0,a=0;for(let e=0;e<n.length-1;e++){let o=n[e],s=n[e+1],c=s[0]-o[0],l=s[1]-o[1],u=s[2]-o[2],d=c*c+l*l+u*u||1,f=t[0]-o[0],p=t[1]-o[1],m=t[2]-o[2],h=(f*c+p*l+m*u)/d;h=Math.max(0,Math.min(1,h));let g=o[0]+c*h,_=o[1]+l*h,v=o[2]+u*h,y=t[0]-g,b=t[1]-_,x=t[2]-v,S=y*y+b*b+x*x;S<i&&(i=S,a=r[e]+Math.sqrt(d)*h)}return{arcLen:a,distSq:i}}function Ui(e){let t=[0];for(let n=1;n<e.length;n++){let r=e[n-1],i=e[n];t.push(t[n-1]+Math.hypot(i[0]-r[0],i[1]-r[1],i[2]-r[2]))}return{points:e,cumLen:t,totalLen:t[t.length-1]||1}}function Wi(){if(!Fn||!wr)return;let e=wr.length/3,t=new Float32Array(e).fill(Ur),n=new Float32Array(e).fill(1);if(Q.length>0)for(let r=0;r<e;r++){if(!Tr[r])continue;let e=Er[r],i=[wr[r*3],wr[r*3+1],wr[r*3+2]],a=Ur,o=1/0,s=1;for(let t of Q){if(t.enabledObjectIndices&&!t.enabledObjectIndices.includes(e))continue;let{arcLen:n,distSq:r}=Hi(t,i);if(r<o){o=r;let e=t.masterTotalLen||t.totalLen;a=e>0?((t.sourceOffset||0)+n)/e:0,s=e||1}}t[r]=a,n[r]=s}N.bindBuffer(N.ARRAY_BUFFER,kn),N.bufferData(N.ARRAY_BUFFER,t,N.STATIC_DRAW),N.bindBuffer(N.ARRAY_BUFFER,An),N.bufferData(N.ARRAY_BUFFER,n,N.STATIC_DRAW)}function Gi(){Q.length>0?localStorage.setItem(Rr,JSON.stringify(Q.map(e=>({points:e.points,touchedObjectIndices:e.touchedObjectIndices,enabledObjectIndices:e.enabledObjectIndices,sourceOffset:e.sourceOffset,masterTotalLen:e.masterTotalLen})))):localStorage.removeItem(Rr)}function Ki(e){return e.map(e=>{let t=Ui(e.points);return{...t,touchedObjectIndices:e.touchedObjectIndices,enabledObjectIndices:e.enabledObjectIndices,sourceOffset:e.sourceOffset||0,masterTotalLen:e.masterTotalLen||t.totalLen,reversed:!1}})}function qi(){Q=Ki(zr),$r=null,Gi(),Wi(),Z()}var Ji=Math.max(1,window.devicePixelRatio||1);2*Ji,11*Ji;function Yi(){if(N.viewport(0,0,n.width,n.height),se){let e=pe[O].bg;N.clearColor(e[0],e[1],e[2],1)}else N.clearColor(0,0,0,1);if(N.clear(N.COLOR_BUFFER_BIT|N.DEPTH_BUFFER_BIT),qt!==null){let e=performance.now(),t=Math.min(1,Math.max(0,e-qt-$t)/Qt),n=tn(t);Ot=U.rotX+(Jt-U.rotX)*n,kt=U.rotY+(Yt-U.rotY)*n;let r=Zt===0?1:Math.min(1,(e-qt)/en);if(Zt!==0){let e=nn(r);x(U.sizePercent+(Xt-U.sizePercent)*e),vn()}rn?(Nt=U.parTargetX*(1-n),Pt=U.parTargetY*(1-n),B=U.parX*(1-n),V=U.parY*(1-n)):bn(),t>=1&&r>=1&&(qt=null,U=null)}else bn();if(on){let e=Math.min(1,(performance.now()-sn)/un);kt=cn+(ln-cn)*dn(e),e>=1&&(on=!1)}let e=Ot+B,t=kt+V,r=G===null?null:W[G];if(dr){let e=performance.now(),t=Math.min(1,(e-fr)/_r),n=vr(t);K=[0,1,2].map(e=>pr[e]+(mr[e]-pr[e])*n);let r=Math.min(1,Math.max(0,e-fr-xr)/yr),i=br(r);J=hr+(gr-hr)*i,t>=1&&r>=1&&(dr=!1,Y=[0,0,0],Kn=0,X=null),qn=!1}else{let e=r?lr(G):{center:[0,0,0],zoomGoal:1},t=e.center,n=e.zoomGoal,i=performance.now(),a=X===null?0:Math.min(Qn,(i-X)/1e3);X=i;let o=[0,0,0];for(let e=0;e<3;e++)[o[e],Y[e]]=Ri(K[e],Y[e],t[e],a);K=o,[J,Kn]=Ri(J,Kn,n,a,Xn,Zn),qn=!r&&Math.hypot(...K)<$n&&Math.hypot(...Y)<$n&&Math.abs(J-1)<$n&&Math.abs(Kn)<$n}let i=ht*b*J,[a,o]=Bi(e,t,i),[s,c,l]=Vi(),_=lt(a,o,wt);_=at(_,st(e)),_=at(_,ct(t)),_=at(_,lt(s,c,l)),_=at(_,ut(i)),N.useProgram(P),N.uniformMatrix4fv(Oe,!1,_),N.uniformMatrix4fv(ke,!1,pt);let v=re*Math.PI/180,y=ie*Math.PI/180;N.uniform3f(Ae,Math.cos(y)*Math.cos(v),Math.sin(y),Math.cos(y)*Math.sin(v)),N.uniform1f(je,ae/100),N.uniform1i(Me,+!!se);let S=pe[O].fill;N.uniform3f(Ne,S[0],S[1],S[2]),N.uniform3f(Pe,me[0],me[1],me[2]);let k=pe[O].line;N.uniform3f(Ye,k[0],k[1],k[2]),N.uniform1f(Xe,C),N.uniform1f(Ze,w),N.uniform1f(Qe,T/100),N.uniform1f($e,E);let A=D/100;N.uniform1f(et,A),N.uniform1f(tt,A*ee),N.bindBuffer(N.ARRAY_BUFFER,wn),N.enableVertexAttribArray(xe),N.vertexAttribPointer(xe,3,N.FLOAT,!1,0,0),N.bindBuffer(N.ARRAY_BUFFER,Tn),N.enableVertexAttribArray(Se),N.vertexAttribPointer(Se,3,N.FLOAT,!1,0,0),N.bindBuffer(N.ARRAY_BUFFER,En),N.enableVertexAttribArray(Ce),N.vertexAttribPointer(Ce,3,N.FLOAT,!1,0,0),N.bindBuffer(N.ARRAY_BUFFER,Dn),N.enableVertexAttribArray(we),N.vertexAttribPointer(we,1,N.FLOAT,!1,0,0),N.bindBuffer(N.ARRAY_BUFFER,On),N.enableVertexAttribArray(De),N.vertexAttribPointer(De,1,N.FLOAT,!1,0,0),N.bindBuffer(N.ARRAY_BUFFER,kn),N.enableVertexAttribArray(Te),N.vertexAttribPointer(Te,1,N.FLOAT,!1,0,0),N.bindBuffer(N.ARRAY_BUFFER,An),N.enableVertexAttribArray(Ee),N.vertexAttribPointer(Ee,1,N.FLOAT,!1,0,0);let j=se&&Fn&&Q.length>0,M=.02,te=0,ne=0,oe=0,ce=0;if(j){M=Math.max(.02,Br*u*4),ne=M*Yr,te=1+2*ne;let e=Vr/(100/d*Jr);oe=performance.now()*e,ce=g/Vr}if(N.uniform1i(Fe,+!!j),j&&(N.uniform1f(Ie,oe),N.uniform1f(Le,Vr),N.uniform1f(Re,te),N.uniform1f(ze,ne),N.uniform1f(Be,ce),N.uniform1f(Ve,M),N.uniform3f(He,ge[0],ge[1],ge[2]),N.uniform3f(Ue,_e[0],_e[1],_e[2]),N.uniform1f(We,M*Hr*Vr),N.uniform1f(Ge,f/100*M*Vr),N.uniform1f(Ke,m/100*M*Vr),N.uniform1f(qe,h),N.uniform1i(Je,+!!p)),se&&(N.enable(N.POLYGON_OFFSET_FILL),N.polygonOffset(1,1)),N.drawArrays(N.TRIANGLES,0,Nn),se){N.disable(N.POLYGON_OFFSET_FILL),N.useProgram(F),N.uniformMatrix4fv(nt,!1,_),N.uniformMatrix4fv(rt,!1,pt),N.uniform1f(it,1),N.bindBuffer(N.ARRAY_BUFFER,jn),N.enableVertexAttribArray(I),N.vertexAttribPointer(I,3,N.FLOAT,!1,0,0),N.bindBuffer(N.ARRAY_BUFFER,Mn),N.enableVertexAttribArray(L),N.vertexAttribPointer(L,3,N.FLOAT,!1,0,0),N.drawArrays(N.LINES,0,Pn);let e=[],t=[],r=[],a=at(pt,_);if(e.length>0||r.length>0){if(N.uniformMatrix4fv(nt,!1,dt),N.uniformMatrix4fv(rt,!1,dt),N.enableVertexAttribArray(I),N.disableVertexAttribArray(L),N.enable(N.BLEND),N.blendFunc(N.SRC_ALPHA,N.ONE_MINUS_SRC_ALPHA),N.uniform1f(it,qr),e.length>0){let t=Fi(e,a,n.width,n.height,Kr);N.bindBuffer(N.ARRAY_BUFFER,ni),N.bufferData(N.ARRAY_BUFFER,t,N.DYNAMIC_DRAW),N.vertexAttribPointer(I,3,N.FLOAT,!1,0,0),N.vertexAttrib3f(L,Wr[0],Wr[1],Wr[2]),N.drawArrays(N.TRIANGLES,0,t.length/3)}if(r.length>0){let e=Fi(r,a,n.width,n.height,Kr);N.bindBuffer(N.ARRAY_BUFFER,ni),N.bufferData(N.ARRAY_BUFFER,e,N.DYNAMIC_DRAW),N.vertexAttribPointer(I,3,N.FLOAT,!1,0,0),N.vertexAttrib3f(L,Gr[0],Gr[1],Gr[2]),N.drawArrays(N.TRIANGLES,0,e.length/3)}N.disable(N.BLEND),N.uniform1f(it,1)}if(ti&&e.length>0){N.uniformMatrix4fv(nt,!1,dt),N.uniformMatrix4fv(rt,!1,dt),N.enableVertexAttribArray(I),N.enableVertexAttribArray(L);let n=e;if(n.length>0){let e=new Set(t),r=new Set(n.map(e=>e[e.length-1])),i=new Map;for(let t of n)for(let n of t)e.has(n)||i.set(n,(i.get(n)||0)+1);let o=[],s=[],c=[];for(let[e,t]of i)t>=2?s.push(e):r.has(e)?c.push(e):o.push(e);di(o,a,fi,pi,mi),di(s,a,hi,gi,_i),di(c,a,xi,Si,Ci),di(t,a,vi,yi,bi)}}if(!Gn){let e=G!==null&&W[G]?K:[-s/i,-c/i,-l/i];if(N.uniformMatrix4fv(nt,!1,dt),N.uniformMatrix4fv(rt,!1,dt),Math.abs(e[1])>1e-4){let t=Ai(e,[e[0],0,e[2]],a,n.width,n.height,Ei,Di,Oi);N.bindBuffer(N.ARRAY_BUFFER,ki),N.bufferData(N.ARRAY_BUFFER,t,N.DYNAMIC_DRAW),N.enableVertexAttribArray(I),N.vertexAttribPointer(I,3,N.FLOAT,!1,0,0),N.disableVertexAttribArray(L),N.vertexAttrib3f(L,Ti[0],Ti[1],Ti[2]),N.drawArrays(N.TRIANGLES,0,t.length/3)}let t=li([a[0]*e[0]+a[4]*e[1]+a[8]*e[2]+a[12],a[1]*e[0]+a[5]*e[1]+a[9]*e[2]+a[13],a[2]*e[0]+a[6]*e[1]+a[10]*e[2]+a[14]],n.width,n.height,ri);N.bindBuffer(N.ARRAY_BUFFER,si),N.bufferData(N.ARRAY_BUFFER,t,N.DYNAMIC_DRAW),N.enableVertexAttribArray(I),N.vertexAttribPointer(I,3,N.FLOAT,!1,24,0),N.enableVertexAttribArray(L),N.vertexAttribPointer(L,3,N.FLOAT,!1,24,12),N.drawArrays(N.TRIANGLES,0,t.length/6)}}}var Xi=.5,Zi=4096,$=1,Qi=0,$i=0;function ea(){n.width=Math.max(1,Math.round(Qi*$)),n.height=Math.max(1,Math.round($i*$))}function ta(){let t=n.clientWidth,r=n.clientHeight,i=Math.round(t*e),a=Math.round(r*e),o=Math.min(1,Zi/Math.max(i,a));Qi=Math.round(i*o),$i=Math.round(a*o),ea(),mt(t/r),or()}var na=20;function ra(e,t,n){return t-e>na&&t-n>na}function ia(e){let t=e.trim().toLowerCase().replace(/\.\d{3}$/,``);return t===`hatch`?1:t===`dot`||t===`dots`?2:t===`plus`||t===`cross`?3:0}var aa=250,oa=performance.now(),sa=0,ca=0,la=oa;Math.max(1,window.devicePixelRatio||1);var ua=1/0,da=-1/0,fa=1/0,pa=-1/0,ma=1e3/60,ha=1.05,ga=.1,_a=2,va=8,ya=4,ba=0,xa=0,Sa=0;function Ca(e){ba++,!(ba<=ya)&&(e>ma*1.15?(xa++,Sa=0):e<=ma*ha?(Sa++,xa=0):(xa=0,Sa=0),xa>=_a&&$>Xi?($=Math.max(Xi,$-ga),ea(),xa=0):Sa>=va&&$<1&&($=Math.min(1,$+ga),ea(),Sa=0))}function wa(e){e??=performance.now();let t=e-oa;if(oa=e,sa++,ca+=t,e-la>=aa){let t=ca/sa,n=1e3/t;ua=Math.min(ua,n),da=Math.max(da,n),fa=Math.min(fa,t),pa=Math.max(pa,t),Ca(t),la=e,sa=0,ca=0}}function Ta(e){Yi(),wa(e),requestAnimationFrame(Ta)}window.addEventListener(`resize`,ta),ta(),Ta(),Lr(),window.heroScene={goToTarget:e=>ur(e),goToDefault:()=>Un(),getActiveTarget:()=>G,onTargetChange:e=>{let t=t=>e(t.cameraTargetActiveIndex);return Ln.push(t),()=>{let e=Ln.indexOf(t);e!==-1&&Ln.splice(e,1)}}};